graphics.off()
rm(list=ls())
data <- read.table("pollenCounts.txt", header=TRUE)
attach(data)
data$dif <- antherCount - handCount
attach(data)
data$sdif <- (dif/handCount)*100
attach(data)
quartz(height=9, width=6, family= "Optima-Regular", pointsize=14)
par(mfrow=c(2,1))
plot(antherCount, dif, xlab="Machine count", ylab="Deviation from hand count", las=1)
plot(antherCount, sdif, xlab="Machine count", ylab="Percent deviation from hand count", las=1)